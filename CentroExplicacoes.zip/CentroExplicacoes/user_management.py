
import os
import cv2
import face_recognition
import pickle

USERS_DIR = "users"


def register_user(name, image_path):
    if not os.path.exists(USERS_DIR):
        os.makedirs(USERS_DIR)

    frame = cv2.imread(image_path)
    if frame is None:
        print("Erro ao carregar a imagem. Verifique o caminho da imagem.")
        return

    face_encodings = face_recognition.face_encodings(frame)
    if face_encodings:
        user_data = {
            'name': name,
            'encoding': face_encodings[0]
        }
        with open(os.path.join(USERS_DIR, f"{name}.pkl"), 'wb') as f:
            pickle.dump(user_data, f)
        print(f"Usuário {name} registrado com sucesso.")
    else:
        print("Nenhum rosto encontrado na imagem. Tente novamente.")


def load_user_encodings():
    user_encodings = []
    for filename in os.listdir(USERS_DIR):
        if filename.endswith(".pkl"):
            with open(os.path.join(USERS_DIR, filename), 'rb') as f:
                user_data = pickle.load(f)
                user_encodings.append(user_data)
    return user_encodings


def recognize_user(image_path):
    user_encodings = load_user_encodings()
    frame = cv2.imread(image_path)
    if frame is None:
        print("Erro ao carregar a imagem. Verifique o caminho da imagem.")
        return None

    face_encodings = face_recognition.face_encodings(frame)
    if face_encodings:
        for encoding in face_encodings:
            matches = face_recognition.compare_faces([user['encoding'] for user in user_encodings], encoding)
            if True in matches:
                match_index = matches.index(True)
                print(f"Bem-vindo, {user_encodings[match_index]['name']}!")
                return user_encodings[match_index]['name']

    print("Usuário não reconhecido.")
    return None
