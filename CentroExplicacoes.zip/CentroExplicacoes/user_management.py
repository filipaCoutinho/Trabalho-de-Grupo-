import cv2
import face_recognition
import os
import sqlite3
import shutil

# Configuração do banco de dados da gestão de alunos
DB_PATH = 'C:\\Users\\filip\\PycharmProjects\\CentroExplicacoes\\CE.db'

# Diretório para armazenar as imagens do reconhecimento facial
USER_IMAGE_DIR = 'user_images'


def init_db():
    # Conecta ao banco de dados
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Verifica se a tabela de alunos já existe
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='utilizadores'")
    table_exists = cursor.fetchone()

    # Se a tabela não existir, crie-a
    if not table_exists:
        cursor.execute('''
            CREATE TABLE utilizadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                username TEXT NOT NULL,
                password TEXT NOT NULL,
                imagem_path TEXT
            )
        ''')
        conn.commit()
    conn.close()



def register_user(name, username, password, image_path):
    # Criar o diretório se não existir
    if not os.path.exists(USER_IMAGE_DIR):
        os.makedirs(USER_IMAGE_DIR)

    # Construir o caminho do arquivo para salvar a imagem
    filename = f"{name.replace(' ', '_')}.jpg"
    image_dest_path = os.path.join(USER_IMAGE_DIR, filename)

    # Copiar a imagem para o diretório de imagens
    shutil.copy(image_path, image_dest_path)

    # Salvar o utilizador no banco de dados
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO utilizadores (nome, username, password, imagem_path) VALUES (?, ?, ?, ?)",
                   (name, username, password, image_dest_path))
    conn.commit()
    conn.close()


def recognize_user(image_path):
    # Carregar imagem e obter codificação facial
    image = face_recognition.load_image_file(image_path)
    face_encodings = face_recognition.face_encodings(image)
    if not face_encodings:
        return None
    face_encoding = face_encodings[0]

    # Conectar ao banco de dados
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Obter todas as imagens do banco de dados
    cursor.execute("SELECT nome, imagem_path FROM utilizadores")
    users = cursor.fetchall()

    # Comparar codificações
    for user in users:
        nome, image_path = user
        user_image = face_recognition.load_image_file(image_path)
        user_face_encodings = face_recognition.face_encodings(user_image)
        if not user_face_encodings:
            continue
        user_face_encoding = user_face_encodings[0]
        distance = face_recognition.face_distance([user_face_encoding], face_encoding)
        if distance < 0.6:  # Defina um limite de distância adequado
            return nome
    return None

# Inicializar o banco de dados
init_db()

