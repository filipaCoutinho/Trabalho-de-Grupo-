import tkinter as tk
from tkinter import filedialog, messagebox
import sqlite3
from user_management import register_user, recognize_user
import os


# Classe para gerir o banco de dados
class BancoDeDados:
    def __init__(self, db_file):
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()

    def criar_tabelas(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS utilizadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                username TEXT NOT NULL,
                password TEXT NOT NULL,
                imagem_path TEXT NOT NULL
            )
        ''')

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS alunos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome VARCHAR(100) NOT NULL,
                telemovel VARCHAR(20),
                email VARCHAR(100),
                morada VARCHAR(200),
                ano_escolaridade INTEGER
            )
        ''')

        self.conn.commit()

    def execute_query(self, query, values=()):
        self.cursor.execute(query, values)
        self.conn.commit()
        return self.cursor.fetchall()


# Classe principal da aplicação
class CentroEstudos:
    def __init__(self, root):
        self.root = root
        self.root.title('Gestão Centro de Esplicações')

        self.banco_de_dados = BancoDeDados('CE.db')
        self.banco_de_dados.criar_tabelas()

        # Criar os menus
        self.criar_menus()

    def criar_menus(self):
        # Criar a barra de menus
        menu_bar = tk.Menu(self.root)
        self.root.config(menu=menu_bar)

        # Menu Utilizadores
        utilizadores_menu = tk.Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label='Utilizadores', menu=utilizadores_menu)
        utilizadores_menu.add_command(label='Registar Utilizador', command=self.janela_registar_utilizador)
        utilizadores_menu.add_command(label='Listar Utilizadores', command=self.janela_listar_utilizadores)
        utilizadores_menu.add_command(label='Apagar Utilizador', command=self.janela_apagar_utilizador)
        utilizadores_menu.add_command(label='Reconhecer Utilizador por Imagem',
                                      command=self.janela_reconhecer_utilizador)

        # Menu Alunos
        alunos_menu = tk.Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label='Alunos', menu=alunos_menu)
        alunos_menu.add_command(label='Registar Alunos', command=self.janela_registar_alunos)
        alunos_menu.add_command(label='Atualizar Aluno', command=self.janela_atualizar_aluno)
        alunos_menu.add_command(label='Apagar Aluno', command=self.janela_apagar_aluno)
        alunos_menu.add_command(label='Listar Alunos', command=self.janela_listar_alunos)

    def janela_registar_utilizador(self):
        registar_utilizador_window = tk.Toplevel(self.root)
        registar_utilizador_window.title('Registar Utilizador')

        def registar_utilizador(nome_entry, username_entry, password_entry):
            nome = nome_entry.get()
            username = username_entry.get()
            password = password_entry.get()
            if nome and username and password:
                image_path = filedialog.askopenfilename()
                if image_path:
                    # Salvar a imagem no diretório específico
                    image_filename = os.path.basename(image_path)
                    image_destination = os.path.join('imagens', image_filename)
                    os.makedirs('imagens', exist_ok=True)  # Cria o diretório se não existir
                    os.rename(image_path, image_destination)
                    # Armazenar apenas o caminho da imagem no banco de dados
                    try:
                        register_user(nome, username, password, image_destination)
                        messagebox.showinfo('Sucesso', 'Utilizador registado com sucesso!')
                        registar_utilizador_window.destroy()
                    except Exception as e:
                        messagebox.showerror('Erro', f'Erro ao registrar utilizador: {str(e)}')
                else:
                    messagebox.showwarning('Aviso', 'Selecione uma imagem.')
            else:
                messagebox.showwarning('Aviso', 'Preencha todos os campos.')

        nome_label = tk.Label(registar_utilizador_window, text='Nome:')
        nome_label.pack()
        nome_entry = tk.Entry(registar_utilizador_window)
        nome_entry.pack()

        username_label = tk.Label(registar_utilizador_window, text='Username:')
        username_label.pack()
        username_entry = tk.Entry(registar_utilizador_window)
        username_entry.pack()

        password_label = tk.Label(registar_utilizador_window, text='Password:')
        password_label.pack()
        password_entry = tk.Entry(registar_utilizador_window, show='*')
        password_entry.pack()

        registar_button = tk.Button(registar_utilizador_window, text='Registar',
                                    command=lambda: registar_utilizador(nome_entry, username_entry, password_entry))
        registar_button.pack()

    def janela_listar_utilizadores(self):
        listar_utilizadores_window = tk.Toplevel(self.root)
        listar_utilizadores_window.title('Listar Utilizadores')

        # Obtenha a lista de utilizadores do banco de dados
        utilizadores = self.banco_de_dados.execute_query('SELECT * FROM utilizadores')

        lista_utilizadores = tk.Listbox(listar_utilizadores_window, width=300, height=300)
        lista_utilizadores.pack()

        for utilizador in utilizadores:
            lista_utilizadores.insert(tk.END, f'Nome: {utilizador[1]}, Username: {utilizador[2]}')

    def janela_apagar_utilizador(self):
        apagar_utilizador_window = tk.Toplevel(self.root)
        apagar_utilizador_window.title('Apagar Utilizador')

        # Função para apagar utilizadores
        def apagar_utilizador():
            nome = nome_entry.get()
            if nome:
                self.banco_de_dados.execute_query('DELETE FROM utilizadores WHERE nome = ?', (nome,))
                if self.banco_de_dados.cursor.rowcount > 0:
                    messagebox.showinfo('Sucesso', 'Utilizador apagado com sucesso!')
                    apagar_utilizador_window.destroy()
                else:
                    messagebox.showwarning('Aviso', 'Utilizador não encontrado.')
            else:
                messagebox.showwarning('Aviso', 'Preencha o campo Nome.')

        nome_label = tk.Label(apagar_utilizador_window, text='Nome:')
        nome_label.pack()
        nome_entry = tk.Entry(apagar_utilizador_window)
        nome_entry.pack()

        apagar_button = tk.Button(apagar_utilizador_window, text='Apagar', command=apagar_utilizador)
        apagar_button.pack()

    def janela_reconhecer_utilizador(self):
        reconhecer_utilizador_window = tk.Toplevel(self.root)
        reconhecer_utilizador_window.title('Reconhecer Utilizador')

        nome_label = tk.Label(reconhecer_utilizador_window, text='Nome:')
        nome_label.pack()
        nome_entry = tk.Entry(reconhecer_utilizador_window)
        nome_entry.pack()

        def reconhecer_utilizador():
            nome = nome_entry.get()
            image_path = filedialog.askopenfilename()
            if image_path:
                user = recognize_user(image_path)
                if user:
                    messagebox.showinfo('Sucesso', f'Utilizador {user} reconhecido com sucesso!')
                else:
                    messagebox.showinfo('Falha', 'Utilizador não reconhecido.')

        selecionar_imagem_button = tk.Button(reconhecer_utilizador_window, text='Selecionar Imagem',
                                             command=reconhecer_utilizador)
        selecionar_imagem_button.pack()

    def janela_registar_alunos(self):
        registar_alunos_window = tk.Toplevel(self.root)
        registar_alunos_window.title('Registar Alunos')

        # Função para registar alunos
        def registar_alunos():
            nome = nome_entry.get()
            telefone = telefone_entry.get()
            email = email_entry.get()
            morada = morada_entry.get()
            ano_escolaridade = ano_escolaridade_entry.get()
            if nome:
                self.banco_de_dados.execute_query(
                    'INSERT INTO alunos (nome, telemovel, email, morada, ano_escolaridade) VALUES (?, ?, ?, ?, ?)',
                    (nome, telefone, email, morada, ano_escolaridade))
                messagebox.showinfo('Sucesso', 'Aluno registado com sucesso!')
                registar_alunos_window.destroy()
            else:
                messagebox.showwarning('Aviso', 'Preencha o campo Nome.')

        nome_label = tk.Label(registar_alunos_window, text='Nome:')
        nome_label.pack()
        nome_entry = tk.Entry(registar_alunos_window)
        nome_entry.pack()

        telefone_label = tk.Label(registar_alunos_window, text='Telefone:')
        telefone_label.pack()
        telefone_entry = tk.Entry(registar_alunos_window)
        telefone_entry.pack()

        email_label = tk.Label(registar_alunos_window, text='Email:')
        email_label.pack()
        email_entry = tk.Entry(registar_alunos_window)
        email_entry.pack()

        morada_label = tk.Label(registar_alunos_window, text='Morada:')
        morada_label.pack()
        morada_entry = tk.Entry(registar_alunos_window)
        morada_entry.pack()

        ano_escolaridade_label = tk.Label(registar_alunos_window, text='Ano de Escolaridade:')
        ano_escolaridade_label.pack()
        ano_escolaridade_entry = tk.Entry(registar_alunos_window)
        ano_escolaridade_entry.pack()

        registar_button = tk.Button(registar_alunos_window, text='Registar', command=registar_alunos)
        registar_button.pack()

    def janela_atualizar_aluno(self):
        atualizar_aluno_window = tk.Toplevel(self.root)
        atualizar_aluno_window.title('Atualizar Aluno')

        # Função para atualizar alunos
        def atualizar_aluno():
            nome = nome_entry.get()
            telefone = telefone_entry.get()
            email = email_entry.get()
            morada = morada_entry.get()
            ano_escolaridade = ano_escolaridade_entry.get()
            if nome:
                self.banco_de_dados.execute_query(
                    'UPDATE alunos SET telemovel = ?, email = ?, morada = ?, ano_escolaridade = ? WHERE nome = ?',
                    (telefone, email, morada, ano_escolaridade, nome))
                if self.banco_de_dados.cursor.rowcount > 0:
                    messagebox.showinfo('Sucesso', 'Dados do aluno atualizados com sucesso!')
                    atualizar_aluno_window.destroy()
                else:
                    messagebox.showwarning('Aviso', 'Aluno não encontrado.')
            else:
                messagebox.showwarning('Aviso', 'Preencha o campo Nome.')

        nome_label = tk.Label(atualizar_aluno_window, text='Nome:')
        nome_label.pack()
        nome_entry = tk.Entry(atualizar_aluno_window)
        nome_entry.pack()

        telefone_label = tk.Label(atualizar_aluno_window, text='Telefone:')
        telefone_label.pack()
        telefone_entry = tk.Entry(atualizar_aluno_window)
        telefone_entry.pack()

        email_label = tk.Label(atualizar_aluno_window, text='Email:')
        email_label.pack()
        email_entry = tk.Entry(atualizar_aluno_window)
        email_entry.pack()

        morada_label = tk.Label(atualizar_aluno_window, text='Morada:')
        morada_label.pack()
        morada_entry = tk.Entry(atualizar_aluno_window)
        morada_entry.pack()

        ano_escolaridade_label = tk.Label(atualizar_aluno_window, text='Ano de Escolaridade:')
        ano_escolaridade_label.pack()
        ano_escolaridade_entry = tk.Entry(atualizar_aluno_window)
        ano_escolaridade_entry.pack()

        atualizar_button = tk.Button(atualizar_aluno_window, text='Atualizar', command=atualizar_aluno)
        atualizar_button.pack()

    def janela_apagar_aluno(self):
        apagar_aluno_window = tk.Toplevel(self.root)
        apagar_aluno_window.title('Apagar Aluno')

        # Função para apagar aluno
        def apagar_aluno():
            nome = nome_entry.get()
            if nome:
                self.banco_de_dados.execute_query('DELETE FROM alunos WHERE nome = ?', (nome,))
                if self.banco_de_dados.cursor.rowcount > 0:
                    messagebox.showinfo('Sucesso', 'Aluno apagado com sucesso!')
                    apagar_aluno_window.destroy()
                else:
                    messagebox.showwarning('Aviso', 'Aluno não encontrado.')
            else:
                messagebox.showwarning('Aviso', 'Preencha o campo Nome.')

        nome_label = tk.Label(apagar_aluno_window, text='Nome:')
        nome_label.pack()
        nome_entry = tk.Entry(apagar_aluno_window)
        nome_entry.pack()

        apagar_button = tk.Button(apagar_aluno_window, text='Apagar', command=apagar_aluno)
        apagar_button.pack()

    def janela_listar_alunos(self):
        listar_alunos_window = tk.Toplevel(self.root)
        listar_alunos_window.title('Listar Alunos')

        # Obtenha a lista de alunos do banco de dados
        alunos = self.banco_de_dados.execute_query('SELECT * FROM alunos')

        lista_alunos = tk.Listbox(listar_alunos_window, width=300, height=300)
        lista_alunos.pack()

        for aluno in alunos:
            lista_alunos.insert(tk.END,
                                f'Nome: {aluno[1]}, Telefone: {aluno[2]}, Email: {aluno[3]}, Morada: {aluno[4]}, Ano de Escolaridade: {aluno[5]}')


# Cria a janela principal da aplicação
root = tk.Tk()
app = CentroEstudos(root)
root.mainloop()
