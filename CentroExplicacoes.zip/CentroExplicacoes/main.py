from user_management import register_user, recognize_user

def main():
    while True:
        print("1. Registrar usuário")
        print("2. Reconhecer usuário")
        print("3. Sair")
        choice = input("Escolha uma opção: ")

        if choice == '1':
            name = input("Digite o nome do usuário: ")
            image_path = input("Digite o caminho da imagem do usuário: ")
            register_user(name, image_path)
        elif choice == '2':
            image_path = input("Digite o caminho da imagem para reconhecimento: ")
            user = recognize_user(image_path)
            if user:
                print(f"Usuário {user} reconhecido com sucesso!")
            else:
                print("Usuário não reconhecido.")
        elif choice == '3':
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()
